/******************************************************************************/
/* Important Fall 2025 CSCI 402 usage information:                            */
/*                                                                            */
/* This fils is part of CSCI 402 kernel programming assignments at USC.       */
/*         53616c7465645f5fd1e93dbf35cbffa3aef28f8c01d8cf2ffc51ef62b26a       */
/*         f9bda5a68e5ed8c972b17bab0f42e24b19daa7bd408305b1f7bd6c7208c1       */
/*         0e36230e913039b3046dd5fd0ba706a624d33dbaa4d6aab02c82fe09f561       */
/*         01b0fd977b0051f0b0ce0c69f7db857b1b5e007be2db6d42894bf93de848       */
/*         806d9152bd5715e9                                                   */
/* Please understand that you are NOT permitted to distribute or publically   */
/*         display a copy of this file (or ANY PART of it) for any reason.    */
/* If anyone (including your prospective employer) asks you to post the code, */
/*         you must inform them that you do NOT have permissions to do so.    */
/* You are also NOT permitted to remove or alter this comment block.          */
/* If this comment block is removed or altered in a submitted file, 20 points */
/*         will be deducted.                                                  */
/******************************************************************************/

#include "types.h"
#include "globals.h"
#include "kernel.h"
#include "errno.h"

#include "util/gdb.h"
#include "util/init.h"
#include "util/debug.h"
#include "util/string.h"
#include "util/printf.h"

#include "mm/mm.h"
#include "mm/page.h"
#include "mm/pagetable.h"
#include "mm/pframe.h"

#include "vm/vmmap.h"
#include "vm/shadowd.h"
#include "vm/shadow.h"
#include "vm/anon.h"

#include "main/acpi.h"
#include "main/apic.h"
#include "main/interrupt.h"
#include "main/gdt.h"

#include "proc/sched.h"
#include "proc/proc.h"
#include "proc/kthread.h"

#include "drivers/dev.h"
#include "drivers/blockdev.h"
#include "drivers/disk/ata.h"
#include "drivers/tty/virtterm.h"
#include "drivers/pci.h"

#include "api/exec.h"
#include "api/syscall.h"

#include "fs/vfs.h"
#include "fs/vnode.h"
#include "fs/vfs_syscall.h"
#include "fs/fcntl.h"
#include "fs/stat.h"

#include "test/kshell/kshell.h"
#include "test/s5fs_test.h"

GDB_DEFINE_HOOK(initialized)

void      *bootstrap(int arg1, void *arg2);
void      *idleproc_run(int arg1, void *arg2);
kthread_t *initproc_create(void);
void      *initproc_run(int arg1, void *arg2);
void      *final_shutdown(void);

/**
 * This function is called from kmain, however it is not running in a
 * thread context yet. It should create the idle process which will
 * start executing idleproc_run() in a real thread context.  To start
 * executing in the new process's context call context_make_active(),
 * passing in the appropriate context. This function should _NOT_
 * return.
 *
 * Note: Don't forget to set curproc and curthr appropriately.
 *
 * @param arg1 the first argument (unused)
 * @param arg2 the second argument (unused)
 */
void *
bootstrap(int arg1, void *arg2)
{
        /* If the next line is removed/altered in your submission, 20 points will be deducted. */
        dbgq(DBG_TEST, "SIGNATURE: 53616c7465645f5fdb485beb2f30c9baf10b74e3ec210e09942fec0b3cdab5bf2c33053f400c1dba587632c443b03d42\n");
        /* necessary to finalize page table information */
        pt_template_init();

        /* Create the idle process (PID 0) */
        proc_t *idle_proc = proc_create("idle");
        KASSERT(idle_proc != NULL && "failed to create idle process");
        KASSERT(PID_IDLE == idle_proc->p_pid && "idle process should have PID 0");
        dbg(DBG_PRINT, "(GRADING1A 1.b)\n");

        /* Create the idle thread */
        kthread_t *idle_thr = kthread_create(idle_proc, idleproc_run, 0, NULL);
        KASSERT(idle_thr != NULL && "failed to create idle thread");

        /* Set the current process and thread */
        curproc = idle_proc;
        curthr = idle_thr;
        KASSERT(NULL != curproc);
        KASSERT(PID_IDLE == curproc->p_pid);
        KASSERT(NULL != curthr);
        dbg(DBG_PRINT, "(GRADING1A 1.a)\n");

        /* Switch to the idle thread's context - this should NEVER return */
        context_make_active(&idle_thr->kt_ctx);

        panic("weenix returned to bootstrap()!!! BAD!!!\n");
        return NULL;
}

/**
 * Once we're inside of idleproc_run(), we are executing in the context of the
 * first process-- a real context, so we can finally begin running
 * meaningful code.
 *
 * This is the body of process 0. It should initialize all that we didn't
 * already initialize in kmain(), launch the init process (initproc_run),
 * wait for the init process to exit, then halt the machine.
 *
 * @param arg1 the first argument (unused)
 * @param arg2 the second argument (unused)
 */
void *
idleproc_run(int arg1, void *arg2)
{
        int status;
        pid_t child;

        /* create init proc */
        kthread_t *initthr = initproc_create();
        init_call_all();
        GDB_CALL_HOOK(initialized);

        /* Create other kernel threads (in order) */

#ifdef __VFS__
        /* Once you have VFS remember to set the current working directory
         * of the idle and init processes */
        curproc->p_cwd = vfs_root_vn;
        vref(vfs_root_vn);
        initthr->kt_proc->p_cwd = vfs_root_vn;
        vref(vfs_root_vn);

        /* Here you need to make the null, zero, and tty devices using mknod */
        /* You can't do this until you have VFS, check the include/drivers/dev.h
         * file for macros with the device ID's you will need to pass to mknod */
        do_mkdir("/dev");
        do_mknod("/dev/null", S_IFCHR, MEM_NULL_DEVID);
        do_mknod("/dev/zero", S_IFCHR, MEM_ZERO_DEVID);
        do_mknod("/dev/tty0", S_IFCHR, MKDEVID(2, 0));
        do_mknod("/dev/tty1", S_IFCHR, MKDEVID(2, 1));
        do_mknod("/dev/tty2", S_IFCHR, MKDEVID(2, 2));
#endif

        /* Finally, enable interrupts (we want to make sure interrupts
         * are enabled AFTER all drivers are initialized) */
        intr_enable();

        /* Run initproc */
        sched_make_runnable(initthr);
        /* Now wait for it */
        child = do_waitpid(-1, 0, &status);
        KASSERT(PID_INIT == child);

        return final_shutdown();
}

/**
 * This function, called by the idle process (within 'idleproc_run'), creates the
 * process commonly refered to as the "init" process, which should have PID 1.
 *
 * The init process should contain a thread which begins execution in
 * initproc_run().
 *
 * @return a pointer to a newly created thread which will execute
 * initproc_run when it begins executing
 */
kthread_t *
initproc_create(void)
{
        /* Create the init process (PID 1) */
        proc_t *p = proc_create("init");
        KASSERT(NULL != p);
        KASSERT(PID_INIT == p->p_pid);
        dbg(DBG_PRINT, "(GRADING1A 1.b)\n");

        /* Create the init thread */
        kthread_t *thr = kthread_create(p, initproc_run, 0, NULL);
        KASSERT(NULL != thr);
        dbg(DBG_PRINT, "(GRADING1A 1.b)\n");

        return thr;
}


/**
 * The init thread's function changes depending on how far along your Weenix is
 * developed. Before VM/FI, you'll probably just want to have this run whatever
 * tests you've written (possibly in a new process). After VM/FI, you'll just
 * exec "/sbin/init".
 *
 * Both arguments are unused.
 *
 * @param arg1 the first argument (unused)
 * @param arg2 the second argument (unused)
 */
/* Kshell command handlers for tests */
static int kshell_faber_test(kshell_t *ksh, int argc, char **argv)
{
        extern void *faber_thread_test(int arg1, void *arg2);
        int status;
        pid_t child_pid;

        /* Create process and thread for faber_thread_test */
        proc_t *test_proc = proc_create("faber_test");
        KASSERT(test_proc != NULL && "failed to create test process");

        kthread_t *test_thr = kthread_create(test_proc, faber_thread_test, 0, NULL);
        KASSERT(test_thr != NULL && "failed to create test thread");
        sched_make_runnable(test_thr);

        /* Wait for ALL children to complete (including reparented ones) */
        while ((child_pid = do_waitpid(-1, 0, &status)) != -ECHILD) {
                /* Keep waiting for all children */
        }

        return 0;
}

static int kshell_sunghan_test(kshell_t *ksh, int argc, char **argv)
{
        extern void *sunghan_test(int arg1, void *arg2);
        int status;
        pid_t child_pid;

        /* Create process and thread for sunghan_test */
        proc_t *test_proc = proc_create("sunghan_test");
        KASSERT(test_proc != NULL && "failed to create sunghan_test process");

        kthread_t *test_thr = kthread_create(test_proc, sunghan_test, 0, NULL);
        KASSERT(test_thr != NULL && "failed to create sunghan_test thread");
        sched_make_runnable(test_thr);

        /* Wait for ALL children to complete (including reparented ones) */
        while ((child_pid = do_waitpid(-1, 0, &status)) != -ECHILD) {
                /* Keep waiting for all children */
        }

        return 0;
}

static int kshell_sunghan_deadlock_test(kshell_t *ksh, int argc, char **argv)
{
        extern void *sunghan_deadlock_test(int arg1, void *arg2);
        int status;
        pid_t child_pid;

        /* Create process and thread for sunghan_deadlock_test */
        proc_t *test_proc = proc_create("sunghan_deadlock_test");
        KASSERT(test_proc != NULL && "failed to create sunghan_deadlock_test process");

        kthread_t *test_thr = kthread_create(test_proc, sunghan_deadlock_test, 0, NULL);
        KASSERT(test_thr != NULL && "failed to create sunghan_deadlock_test thread");
        sched_make_runnable(test_thr);

        /* Wait for ALL children to complete (including reparented ones) */
        while ((child_pid = do_waitpid(-1, 0, &status)) != -ECHILD) {
                /* Keep waiting for all children */
        }

        return 0;
}

void *
initproc_run(int arg1, void *arg2)
{
        int status;
        pid_t child_pid;

        dbg(DBG_PRINT, "(GRADING1A)\n");

        /* Verify we're running in init process */
        KASSERT(curproc != NULL && "current process should not be NULL");
        KASSERT(curproc->p_pid == PID_INIT && "should be running in init process");

#ifdef __DRIVERS__
        /* Register kshell commands for tests */
        kshell_add_command("faber", kshell_faber_test, "Run faber_thread_test().");
        kshell_add_command("sunghan", kshell_sunghan_test, "Run sunghan_test().");
        kshell_add_command("deadlock", kshell_sunghan_deadlock_test, "Run sunghan_deadlock_test().");

        /* Launch kshell on tty 0 */
        proc_t *kshell_proc = proc_create("kshell");
        KASSERT(kshell_proc != NULL && "failed to create kshell process");

        kthread_t *kshell_thr = kthread_create(kshell_proc, kshell_proc_run, 0, NULL);
        KASSERT(kshell_thr != NULL && "failed to create kshell thread");
        sched_make_runnable(kshell_thr);
#else
        /* No drivers - run test based on CS402INITCHOICE */
        extern void *faber_thread_test(int arg1, void *arg2);
        extern void *sunghan_test(int arg1, void *arg2);
        extern void *sunghan_deadlock_test(int arg1, void *arg2);

        proc_t *test_proc = NULL;
        kthread_t *test_thr = NULL;

#if CS402INITCHOICE == 0
        test_proc = proc_create("faber_test");
        KASSERT(test_proc != NULL && "failed to create test process");
        test_thr = kthread_create(test_proc, faber_thread_test, 0, NULL);
        KASSERT(test_thr != NULL && "failed to create test thread");
        sched_make_runnable(test_thr);
#elif CS402INITCHOICE == 1
        test_proc = proc_create("sunghan_test");
        KASSERT(test_proc != NULL && "failed to create sunghan_test process");
        test_thr = kthread_create(test_proc, sunghan_test, 0, NULL);
        KASSERT(test_thr != NULL && "failed to create sunghan_test thread");
        sched_make_runnable(test_thr);
#elif CS402INITCHOICE == 2
        test_proc = proc_create("sunghan_deadlock_test");
        KASSERT(test_proc != NULL && "failed to create sunghan_deadlock_test process");
        test_thr = kthread_create(test_proc, sunghan_deadlock_test, 0, NULL);
        KASSERT(test_thr != NULL && "failed to create sunghan_deadlock_test thread");
        sched_make_runnable(test_thr);
#endif
#endif

        /* Wait for ALL children to exit (including reparented ones) */
        while ((child_pid = do_waitpid(-1, 0, &status)) != -ECHILD) {
                dbg(DBG_PRINT, "(GRADING1A)\n");
        }

        dbg(DBG_PRINT, "(GRADING1A)\n");

        return NULL;
}
